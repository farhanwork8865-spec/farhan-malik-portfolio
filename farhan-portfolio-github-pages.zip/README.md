# Farhan Malik Portfolio

Static website for GitHub Pages. No build step, no frameworks.

- `index.html` is the complete website (photo, logo and project screenshots are embedded in it).
- `404.html` sends wrong addresses back to the portfolio.
- `.nojekyll` tells GitHub Pages to publish the files exactly as they are.
- `assets/` holds copies of the images and videos for your records. The site does not need it to run.

Fonts (Poppins, Inter) load from Google Fonts, so they need an internet connection.
